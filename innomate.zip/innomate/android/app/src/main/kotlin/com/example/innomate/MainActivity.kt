package com.example.innomate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
