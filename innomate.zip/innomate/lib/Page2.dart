import 'package:flutter/material.dart';

class Page2 extends StatelessWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: Center(
      child: Text(
        "BookMarks",style: TextStyle(
          fontWeight: FontWeight.bold,fontSize: 30)),),);
  }
}
