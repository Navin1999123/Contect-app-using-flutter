import 'package:flutter/material.dart';
import 'package:innomate/Page1.dart';
import 'package:innomate/Page2.dart';

import 'ProfilePage.dart';
// import 'Tab/Page1.dart';
// import 'Tab/Page2.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size.height;
    final screenWidthSize = MediaQuery.of(context).size.width;
    return DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(100),
            child: AppBar(
              backgroundColor: Colors.white,
              title: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: screenSize * .40,
                    height: screenSize*.05,
                    child: TextField(
                      decoration: InputDecoration(
                          hintText: 'Search Here',
                          border: OutlineInputBorder()),
                    ),
                  ),
                ],
              ),
              actions: [
                GestureDetector(
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (BuildContext context) => ProfilePage(
                                screenSize: screenSize,
                              )),
                    );
                  },
                  child: CircleAvatar(
                    radius: 23,
                    backgroundColor: Colors.pink,
                  ),
                ),
              ],
              elevation: 0,
              bottom: TabBar(
                  unselectedLabelColor: Colors.redAccent,
                  indicatorSize: TabBarIndicatorSize.label,
                  indicator: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: Colors.redAccent),
                  tabs: [
                    Tab(
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            border:
                                Border.all(color: Colors.redAccent, width: 1)),
                        child: Align(
                          alignment: Alignment.center,
                          child: Text("Users"),
                        ),
                      ),
                    ),
                    Tab(
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            border:
                                Border.all(color: Colors.redAccent, width: 1)),
                        child: Align(
                          alignment: Alignment.center,
                          child: Text("Bookmarked users"),
                        ),
                      ),
                    ),
                  ]),
            ),
          ),
          body: Padding(
            padding: const EdgeInsets.all(10.0),
            child: TabBarView(children: [
              Center(
                  child: Page1(
                screenSize: screenSize,
              )),
              Center(child: Page2()),
            ]),
          ),
        ));
  }
}
