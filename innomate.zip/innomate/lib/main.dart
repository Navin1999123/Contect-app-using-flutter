import 'package:flutter/material.dart';
import 'package:innomate/HomePage.dart';
// import 'package:task04/Innomate/HomePage.dart';
// import 'package:task04/getOtp/body.dart';
// import 'package:task04/top.dart';
// import '../Page/HomeScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          primarySwatch: Colors.blue,
          textTheme: TextTheme(
            headline1: TextStyle(
                color: Colors.indigo.shade400,
                fontWeight: FontWeight.bold,
                fontSize: 29),
            headline2: TextStyle(
                color: Colors.indigo.shade300,
                fontWeight: FontWeight.bold,
                fontSize: 27),
          )),
      home:HomePage()
    );
  }
}