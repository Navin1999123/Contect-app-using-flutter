import 'package:flutter/material.dart';
import 'package:innomate/HomePage.dart';
// import 'package:task04/Innomate/HomePage.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key, required this.screenSize}) : super(key: key);
  final double screenSize;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                    builder: (BuildContext context) => HomePage()));
          },
        ),
        actions: [
          IconButton(
              onPressed: () {}, icon: Icon(Icons.share, color: Colors.black)),
          IconButton(
              onPressed: () {},
              icon: Icon(Icons.settings_outlined, color: Colors.black)),
        ],
      ),
      body: Container(
        margin: EdgeInsets.symmetric(horizontal: screenSize * .02),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 35,
                ),
                SizedBox(
                  width: 10,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Username ",
                        style: TextStyle(
                            fontSize: 20,
                            color: Colors.black,
                            fontWeight: FontWeight.bold)),
                    Text("Navin1231999@github",
                        style: TextStyle(
                            fontSize: 15,
                            color: Colors.black,
                            fontWeight: FontWeight.bold)),
                  ],
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenSize * .02),
              height: screenSize * .07,
              child: TextField(
                decoration: InputDecoration(
                    hintText: 'Update Your Status',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    )),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: screenSize * .02),
              child: Align(
                alignment: Alignment.topLeft,
                child: Text("I am Flutter developer learner",
                    style: TextStyle(fontSize: 15, color: Colors.black)),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              children: [
                Icon(Icons.person_outline),
                Text(
                  '0 ' + 'Followers',
                  style: TextStyle(fontSize: 15, color: Colors.black),
                ),
                SizedBox(
                  width: 10,
                ),
                Text('.'),
                Text(
                  '2 ' + 'Followers',
                  style: TextStyle(fontSize: 15, color: Colors.black),
                ),
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Row(
              children: [
                Icon(
                  Icons.star_border,
                  color: Colors.black,
                ),
                Text(
                  "Popular",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                )
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Container(
                height: screenSize * .30,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: 10,
                  itemBuilder: (context, int index) {
                    return Container(
                      decoration: BoxDecoration(
                          color: Colors.grey,
                          borderRadius: BorderRadius.circular(20)),
                      height: 200,
                      width: screenSize * .60,
                    );
                  },
                  separatorBuilder: (BuildContext context, int index) {
                    return SizedBox(
                      width: 25,
                    );
                  },
                ))
          ],
        ),
      ),
    );
  }
}
