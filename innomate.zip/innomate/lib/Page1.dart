import 'package:flutter/material.dart';

class Page1 extends StatelessWidget {
  const Page1({Key? key, required this.screenSize}) : super(key: key);
  final double screenSize;

  @override
  Widget build(BuildContext context) {
    return Scaffold(body:
    Container(
      child:ListView.separated(
      scrollDirection: Axis.vertical,
      itemCount: 50,
      itemBuilder: (context,int index){
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(20)),

          height: screenSize*.20,
          width: screenSize*.60,
        child: Padding(
          padding: const EdgeInsets.only(left:20.0,right: 20),
          child: Column(children: [
            CircleAvatar(radius: 30,),
            Text("Username",style: TextStyle(fontSize: 20,color: Colors.black,fontWeight: FontWeight.bold)),
            Text("Profile",style: TextStyle(fontSize: 20,color: Colors.black)),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
              ElevatedButton(onPressed: (){}, child: Text("Selected",style: TextStyle(fontSize: 14,color: Colors.black),)),
              ElevatedButton(onPressed: (){}, child: Text("UnSelected",style: TextStyle(fontSize: 14,color: Colors.black))),
            ],)
          ],),
        ),
        );
      }, separatorBuilder: (BuildContext context, int index)
    { return SizedBox(height: 15,); },) ,),);
  }
}
